import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Image,
  ScrollView as ScrollViewReact,
  TextInput,
} from "react-native";
import React, { useState } from "react";
import { ScrollView } from "react-native-virtualized-view";

import { SafeAreaView } from "react-native-safe-area-context";
import MembersHomeHeader from "../../components/headers/MembersHomeHeader";
import { theme, images } from "../../constants";
import { BUTTON } from "../../constants/theme";
import { MagnifyingGlassIcon } from "react-native-heroicons/outline";
import { StarIcon, HeartIcon } from "react-native-heroicons/solid";
import {
  HomeStoreCard,
  HomeMenuCard,
  HomeRecommendedStoreCard,
  PostCard,
  SectionHeader,
  FilterOutlineButton,
} from "../../components";

const menuItems = [
  {
    name: "Mum",
    img: images.menuIcon1,
  },

  {
    name: "Baby",
    img: images.menuIcon2,
  },

  {
    name: "Electronics",
    img: images.menuIcon3,
  },

  {
    name: "Homeware",
    img: images.menuIcon4,
  },

  {
    name: "Health",
    img: images.menuIcon5,
  },

  {
    name: "Beauty",
    img: images.menuIcon6,
  },
  {
    name: "Fashion",
    img: images.menuIcon11,
  },
  {
    name: "More",
    img: images.menuIcon13,
  },
];
const featuredProducts = [
  {
    name: "Bib and Bowl Set",
    img: images.bowl,
  },

  {
    name: "Art Classes for Kids",
    img: images.painter,
  },

  {
    name: "Weekend Yoga Classes",
    img: images.yoga,
  },

  {
    name: "Fruit Blender",
    img: images.blend,
  },

  {
    name: "Art Classes for Kids",
    img: images.painter,
  },
];
const featuredStores = [
  {
    name: "Zen Yoga Studio",
    img: images.yogalogo,
  },

  {
    name: "The Cuddle Club",
    img: images.cuddleclub,
  },

  {
    name: "Dennis Yoga",
    img: images.yogalogo,
  },

  {
    name: "Henry Plants",
    img: images.cuddleclub,
  },

  {
    name: "Art Classes for Kids",
    img: images.cuddleclub,
  },
];
const Home = () => {
  return (
    <>
      <SafeAreaView
        style={styles.container}
        className="bg-white flex-1 pb-0 mb-0 relative"
      >
        <MembersHomeHeader
          title={`Hi,`}
          showPhoto={true}
          showBackButton={false}
        />

        <ScrollView
          nestedScrollEnabled={true}
          scrollEventThrottle={400}
          className="flex-1"
        >
          <View>
            <View className="flex-row px-4 items-center space-x-2 pb-2 mt-4">
              <View className="flex-row flex-1 space-x-2 rounded-2xl bg-gray-100 p-3 py-4">
                <MagnifyingGlassIcon color="gray" />
                <TextInput
                  placeholder="Looking for something amazing?"
                  keyboardType="default"
                />
              </View>
            </View>
            <View className="px-4">
              <PostCard />
            </View>

            <View className=" px-4">
              <SectionHeader title="Categories" />
              <FlatList
                columnWrapperStyle={{ justifyContent: "space-between" }}
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{
                  marginTop: 10,
                  paddingBottom: 50,
                }}
                numColumns={4}
                data={menuItems}
                renderItem={({ item }) => {
                  return <HomeMenuCard item={item} />;
                }}
              />
            </View>
            <View className="px-4">
              <SectionHeader title="Stores" />
            </View>
            <ScrollViewReact
              horizontal
              contentContainerStyle={{
                paddingHorizontal: 15,
              }}
              showsHorizontalScrollIndicator={false}
              className="pt-4 pb-6"
            >
              {featuredStores.map((option, index) => (
                <HomeStoreCard  name={option.name} photo={option.img} key={index} />
              ))}
              {/* <HomeStoreCard />
              <HomeStoreCard /> */}
            </ScrollViewReact>

            <View className="px-4">
              <SectionHeader title="Recommended For You" showButton={true} />
            </View>
            <ScrollViewReact
              horizontal
              contentContainerStyle={{}}
              showsHorizontalScrollIndicator={false}
              className="py-2"
            >
              <FilterOutlineButton selected={true} text="All" />
              <FilterOutlineButton text="Mum" />
              <FilterOutlineButton text="Baby" />
              <FilterOutlineButton text="Eletronics" />
              <FilterOutlineButton text="Health Care" />
            </ScrollViewReact>
            <View className="px-4">
              {featuredProducts.map((option, index) => (
                <HomeRecommendedStoreCard name={option.name} photo={option.img} key={index} />
              ))}
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 0,
    margin: 0,
  },
  featuredImg: {
    shadowColor: "#96e7f7",
    shadowOffset: {
      width: 0,
      height: 9,
    },
    shadowOpacity: 0.48,
    shadowRadius: 11.95,

    elevation: 18,
  },
});

export default Home;
