import { View, Text } from 'react-native'
import React from 'react'

const Credits = () => {
  return (
    <View>
      <Text>Credits</Text>
    </View>
  )
}

export default Credits